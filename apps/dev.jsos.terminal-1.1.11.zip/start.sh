#!/bin/jsh

cat banner.txt

cd $DATA_DIR
HISTFILE=$DATA_DIR/.jsh_history /bin/jsh
